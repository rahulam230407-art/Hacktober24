import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  ArrowDownRight, ArrowRight, ArrowUpRight, Bot, Check, ChevronDown, ChevronUp,
  Code2, ExternalLink, Github, Globe2, Layers3, Menu, Monitor, Radio, Send,
  Sparkles, Terminal, Trophy, X, Zap
} from 'lucide-react';
import { supabase, isSupabaseConfigured } from './supabase';
import './styles.css';

const TRACKS = [
  { id: 'Open-Weight Models', number: '01', icon: Sparkles, title: 'Open-Weight Models', color: 'lime', description: 'Build with open-weight models like Gemma, Llama 3, Mistral, or Qwen. Fine-tune, adapt, and create something distinctly yours.', tags: ['Gemma', 'Llama', 'Mistral', 'Qwen'] },
  { id: 'Agent Frameworks', number: '02', icon: Layers3, title: 'Agent Frameworks & Harnesses', color: 'violet', description: 'Design useful agents with open-source tools, orchestration layers, memory, tools, and execution harnesses.', tags: ['LangGraph', 'CrewAI', 'AutoGen', 'Tools'] },
  { id: 'Local Inference', number: '03', icon: Monitor, title: 'Local Inference', color: 'blue', description: 'Run models on your own hardware or edge devices. Make private, low-latency AI work without a round trip to the cloud.', tags: ['Ollama', 'llama.cpp', 'MLX', 'Edge'] },
];

const RESOURCES = [
  { icon: Bot, type: 'MODEL HUB', title: 'Hugging Face', text: 'Explore models, datasets, and community demos.', url: 'https://huggingface.co/models', tag: 'Discover models' },
  { icon: Terminal, type: 'LOCAL AI', title: 'Ollama', text: 'Get open models running locally with a simple workflow.', url: 'https://ollama.com/', tag: 'Run locally' },
  { icon: Github, type: 'STARTER CODE', title: 'GitHub Explore', text: 'Find open-source projects to learn from and build on.', url: 'https://github.com/explore', tag: 'Browse repos' },
  { icon: Code2, type: 'MODEL TOOLKIT', title: 'Transformers', text: 'A practical library for working with modern ML models.', url: 'https://github.com/huggingface/transformers', tag: 'View toolkit' },
  { icon: Zap, type: 'INFERENCE', title: 'llama.cpp', text: 'Efficient LLM inference across a range of hardware.', url: 'https://github.com/ggml-org/llama.cpp', tag: 'View repository' },
  { icon: Layers3, type: 'AGENTS', title: 'LangGraph', text: 'Build stateful, controllable agent workflows.', url: 'https://github.com/langchain-ai/langgraph', tag: 'Explore agents' },
];

const GUIDELINES = [
  { title: 'Who can participate?', body: 'Open to individual developers and teams. Use technology you have the right to use, respect model and dataset licenses, and make your contribution understandable to reviewers. Teams should submit one project entry and list a representative contact.' },
  { title: 'What are the evaluation criteria?', body: 'Innovation: is the idea useful, original, and thoughtfully scoped? Open-Source Impact: can others inspect, reproduce, reuse, or extend it? Technical Execution: does the project work, explain its architecture, and handle failure cases? Reviewers should be able to run or meaningfully evaluate your build.' },
  { title: 'What should I submit?', body: 'A public GitHub repository, a clear project description, your selected track, and a working demo URL if available. Include a README with setup steps, dependencies, usage examples, limitations, and license. Add screenshots or a demo video where helpful.' },
  { title: 'Can I combine tracks?', body: 'Absolutely. Pick the track that best represents your project, or choose Combined if your build meaningfully uses multiple areas—for example, an open-weight model running locally inside an agent workflow.' },
];

const TRACK_OPTIONS = ['Open-Weight Models', 'Agent Frameworks', 'Local Inference', 'Combined'];

function App() {
  const [modalOpen, setModalOpen] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [openGuideline, setOpenGuideline] = useState(0);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState('');
  const [form, setForm] = useState({ project_name: '', team_name: '', email: '', github_url: '', track: 'Open-Weight Models', demo_url: '', description: '' });
  const [formError, setFormError] = useState('');
  const [sending, setSending] = useState(false);
  const [toast, setToast] = useState(null);

  const loadSubmissions = async () => {
    if (!isSupabaseConfigured) { setLoading(false); setFetchError('Connect Supabase to load live submissions.'); return; }
    setLoading(true);
    const { data, error } = await supabase.from('public_submissions')
      .select('id, created_at, project_name, team_name, github_url, track, demo_url, description')
      .order('created_at', { ascending: false }).limit(50);
    if (error) setFetchError('Could not load submissions. Check your Supabase setup and public_submissions view.');
    else { setSubmissions(data || []); setFetchError(''); }
    setLoading(false);
  };

  useEffect(() => {
    loadSubmissions();
    if (!isSupabaseConfigured) return;
    const channel = supabase.channel('public-submissions-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'submissions' }, () => loadSubmissions())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 4500);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submitProject = async (e) => {
    e.preventDefault();
    setFormError('');
    if (!isSupabaseConfigured) { setFormError('Supabase is not configured. Add your values to .env and restart the dev server.'); return; }
    if (!form.project_name.trim() || !form.team_name.trim() || !form.email.trim() || !form.github_url.trim() || !form.description.trim()) {
      setFormError('Please complete all required fields.'); return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) { setFormError('Enter a valid email address.'); return; }
    const validUrl = (value) => { try { const u = new URL(value); return u.protocol === 'https:' || u.protocol === 'http:'; } catch { return false; } };
    if (!validUrl(form.github_url) || !/github\.com/.test(new URL(form.github_url).hostname)) { setFormError('Enter a valid GitHub repository URL.'); return; }
    if (form.demo_url && !validUrl(form.demo_url)) { setFormError('Demo URL must begin with http:// or https://.'); return; }
    setSending(true);
    const payload = {
      project_name: form.project_name.trim(), team_name: form.team_name.trim(), email: form.email.trim(),
      github_url: form.github_url.trim(), track: form.track, demo_url: form.demo_url.trim() || null,
      description: form.description.trim()
    };
    const { error } = await supabase.from('submissions').insert([payload]);
    setSending(false);
    if (error) { setFormError(error.message.includes('row-level security') ? 'Submission blocked by database permissions. Apply the SQL setup in supabase/schema.sql.' : `Submission failed: ${error.message}`); return; }
    setModalOpen(false);
    setForm({ project_name: '', team_name: '', email: '', github_url: '', track: 'Open-Weight Models', demo_url: '', description: '' });
    setToast({ type: 'success', message: 'Project submitted. Welcome to the challenge!' });
    await loadSubmissions();
  };

  const jumpTo = (id) => { setMobileNav(false); document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }); };
  const openSubmit = () => { setFormError(''); setModalOpen(true); };

  return (
    <div className="app-shell">
      <div className="announcement"><span className="live-dot" /> COMMUNITY BUILD CHALLENGE <span className="announcement-divider">/</span> <span className="mono">SHIP SOMETHING OPEN</span> <ArrowUpRight size={13} /></div>
      <header className="nav-wrap">
        <a href="#top" className="brand" aria-label="Open Source AI Challenge home"><span className="brand-mark"><Code2 size={19} /></span><span>open<span className="brand-accent">build</span><small>.ai</small></span></a>
        <button className="mobile-menu" onClick={() => setMobileNav(!mobileNav)} aria-label="Toggle navigation">{mobileNav ? <X /> : <Menu />}</button>
        <nav className={mobileNav ? 'nav-links nav-open' : 'nav-links'}>
          <button onClick={() => jumpTo('tracks')}>Tracks</button><button onClick={() => jumpTo('guidelines')}>Guidelines</button><button onClick={() => jumpTo('resources')}>Resources</button><button onClick={() => jumpTo('submissions')}>Submissions</button>
        </nav>
        <button className="nav-cta" onClick={openSubmit}>Submit a project <ArrowUpRight size={15} /></button>
      </header>

      <main id="top">
        <section className="hero section-container">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> THE OPEN-SOURCE AI CHALLENGE <span className="eyebrow-pill">2026</span></div>
            <h1>Build the future<br />with <span className="gradient-text">open-source AI.</span></h1>
            <p className="hero-sub">Create original projects powered by open-weight models, agent frameworks, or local inference. Make it useful. Make it open. Make it real.</p>
            <div className="hero-actions"><button className="btn-primary" onClick={openSubmit}>Submit project <ArrowRight size={17} /></button><button className="btn-secondary" onClick={() => jumpTo('guidelines')}>Explore track guidelines <ArrowDownRight size={17} /></button></div>
            <div className="hero-proof"><div className="avatar-stack"><span>AI</span><span>OS</span><span>DEV</span><span>+</span></div><div><strong>Built by the community</strong><small>Open ideas. Shared progress. Real impact.</small></div></div>
          </div>
          <div className="hero-art" aria-label="Decorative abstract AI network illustration">
            <div className="art-grid"></div><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="orbit orbit-three"></div>
            <div className="art-center"><div className="center-glow"></div><Code2 size={56} strokeWidth={1.4} /></div>
            <div className="float-card float-card-top"><span className="float-icon lime-bg"><Terminal size={15} /></span><span><b>open weights</b><small>Model freedom</small></span><span className="float-status"></span></div>
            <div className="float-card float-card-bottom"><span className="float-icon blue-bg"><Radio size={15} /></span><span><b>local-first</b><small>Private by design</small></span><span className="float-status"></span></div>
            <div className="art-label label-left mono">MODEL.INIT()</div><div className="art-label label-right mono">OPEN_SOURCE // 001</div>
          </div>
          <div className="hero-bottomline"><span><span className="status-dot"></span> BUILD IN PUBLIC</span><span className="mono">NO BLACK BOXES. JUST BUILD.</span><span className="scroll-cue">SCROLL TO EXPLORE <ChevronDown size={13} /></span></div>
        </section>

        <section className="tracks-section section-container" id="tracks">
          <div className="section-heading"><div><div className="eyebrow">01 / CHOOSE YOUR PATH</div><h2>Three tracks. <span className="muted-heading">Infinite possibilities.</span></h2></div><p>Pick a lane or combine them. The best projects push beyond the obvious.</p></div>
          <div className="track-grid">{TRACKS.map((track) => { const Icon = track.icon; return <article className={`track-card ${track.color}`} key={track.id}><div className="track-top"><span className="track-number mono">{track.number} / TRACK</span><span className="track-icon"><Icon size={21} /></span></div><h3>{track.title}</h3><p>{track.description}</p><div className="tag-row">{track.tags.map(tag => <span key={tag}>{tag}</span>)}</div><button className="text-link" onClick={() => { setForm({ ...form, track: track.id }); openSubmit(); }}>Build in this track <ArrowUpRight size={15} /></button></article>; })}</div>
          <div className="combine-note"><span className="combine-icon"><Layers3 size={18} /></span><p><strong>Think across tracks.</strong> Building a local agent with an open-weight model? Choose <b>Combined</b> when submitting. Cross-disciplinary projects are encouraged.</p><span className="mono combine-code">01 + 02 + 03</span></div>
        </section>

        <section className="guidelines-section" id="guidelines"><div className="section-container guidelines-layout">
          <div className="guidelines-intro"><div className="eyebrow">02 / THE PLAYBOOK</div><h2>Clear rules.<br /><span className="gradient-text">Room to experiment.</span></h2><p>We care about thoughtful engineering, useful ideas, and work the community can build on. Here is what to know before you ship.</p><div className="criteria-list"><div><span className="criteria-icon"><Sparkles size={16} /></span><span><b>Innovation</b><small>Fresh ideas, real utility</small></span></div><div><span className="criteria-icon"><Globe2 size={16} /></span><span><b>Open-source impact</b><small>Reproducible and reusable</small></span></div><div><span className="criteria-icon"><Code2 size={16} /></span><span><b>Technical execution</b><small>Works, documented, robust</small></span></div></div></div>
          <div className="accordion-list">{GUIDELINES.map((item, i) => <div className={`accordion-item ${openGuideline === i ? 'is-open' : ''}`} key={item.title}><button className="accordion-trigger" onClick={() => setOpenGuideline(openGuideline === i ? -1 : i)} aria-expanded={openGuideline === i}><span className="accordion-num mono">0{i + 1}</span><span>{item.title}</span>{openGuideline === i ? <ChevronUp size={18} /> : <ChevronDown size={18} />}</button>{openGuideline === i && <div className="accordion-content">{item.body}</div>}</div>)}</div>
        </div></section>

        <section className="resources-section section-container" id="resources">
          <div className="section-heading"><div><div className="eyebrow">03 / YOUR TOOLKIT</div><h2>Start with the <span className="muted-heading">good stuff.</span></h2></div><p>Useful tools and communities to get from idea to working prototype faster.</p></div>
          <div className="resource-grid">{RESOURCES.map((r) => { const Icon = r.icon; return <a className="resource-card" href={r.url} target="_blank" rel="noreferrer" key={r.title}><div className="resource-top"><span className="resource-icon"><Icon size={19} /></span><span className="resource-type mono">{r.type}</span><ExternalLink size={15} className="resource-external" /></div><h3>{r.title}</h3><p>{r.text}</p><span className="resource-link">{r.tag} <ArrowUpRight size={14} /></span></a>; })}</div>
        </section>

        <section className="submissions-section" id="submissions"><div className="section-container">
          <div className="section-heading submissions-heading"><div><div className="eyebrow"><span className="live-dot" /> 04 / COMMUNITY BUILDS</div><h2>Fresh off the <span className="gradient-text">terminal.</span></h2><p className="section-description">Projects submitted by builders in the community. Yours could be next.</p></div><button className="btn-primary" onClick={openSubmit}>Add your project <ArrowRight size={16} /></button></div>
          <div className="submission-panel"><div className="panel-head"><div className="panel-title"><span className="panel-live-dot"></span><span>PROJECT_REGISTRY</span><span className="panel-count">{submissions.length} {submissions.length === 1 ? 'PROJECT' : 'PROJECTS'}</span></div><button className="refresh-button" onClick={loadSubmissions} aria-label="Refresh submissions"><Radio size={14} /> Refresh</button></div>
            {loading ? <div className="empty-state"><div className="loader"></div><p>Loading community builds…</p></div> : fetchError ? <div className="empty-state"><Code2 size={25} /><p>{fetchError}</p><button className="text-link" onClick={loadSubmissions}>Try again <ArrowRight size={14} /></button></div> : submissions.length === 0 ? <div className="empty-state"><div className="empty-icon"><Terminal size={24} /></div><h3>It's quiet in here. For now.</h3><p>Be the first to put an open-source AI project on the board.</p><button className="text-link" onClick={openSubmit}>Submit the first project <ArrowRight size={14} /></button></div> : <div className="table-wrap"><table><thead><tr><th>PROJECT</th><th>TEAM</th><th>TRACK</th><th>REPOSITORY</th></tr></thead><tbody>{submissions.map(s => <tr key={s.id}><td><div className="project-cell"><span className="project-mini-icon"><Code2 size={15} /></span><span><b>{s.project_name}</b><small>{s.description}</small></span></div></td><td>{s.team_name}</td><td><span className={`track-badge ${s.track === 'Local Inference' ? 'blue' : s.track === 'Agent Frameworks' ? 'violet' : ''}`}>{s.track}</span></td><td><a className="repo-link" href={s.github_url} target="_blank" rel="noreferrer">View repo <ArrowUpRight size={13} /></a></td></tr>)}</tbody></table></div>}
            <div className="panel-foot"><span><span className="status-dot"></span> LIVE COMMUNITY FEED</span><span className="mono">LATEST 50 SUBMISSIONS</span></div>
          </div>
        </div></section>

        <section className="closing-cta section-container"><div className="closing-glow"></div><div className="closing-content"><div className="eyebrow">YOUR REPO. YOUR RULES. YOUR IMPACT.</div><h2>Open the model.<br /><span className="gradient-text">Open up possibility.</span></h2><p>The next useful AI project might start with you. Ship a prototype, share what you learned, and help make the open ecosystem better.</p><button className="btn-primary" onClick={openSubmit}>Submit your project <ArrowRight size={17} /></button></div><div className="closing-stamp"><Code2 size={38} /><span className="mono">BUILD<br />IN THE<br />OPEN<span className="stamp-dot">.</span></span></div></section>
      </main>

      <footer className="footer"><div className="section-container"><div className="footer-main"><a href="#top" className="brand"><span className="brand-mark"><Code2 size={19} /></span><span>open<span className="brand-accent">build</span><small>.ai</small></span></a><p>A community challenge for people building a more open AI future.</p><div className="footer-social"><a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub"><Github size={17} /></a><a href="https://discord.com/" target="_blank" rel="noreferrer" aria-label="Discord"><Radio size={17} /></a><a href="https://x.com/" target="_blank" rel="noreferrer" aria-label="Twitter X"><ArrowUpRight size={17} /></a></div></div><div className="footer-bottom"><span>© 2026 OpenBuild AI. Built in the open.</span><div><a href="mailto:hello@openbuild.ai?subject=Privacy%20Policy%20Request">Privacy</a><a href="mailto:hello@openbuild.ai?subject=Terms%20of%20Service%20Request">Terms</a><a href="https://github.com/" target="_blank" rel="noreferrer">Open-source spirit <ArrowUpRight size={12} /></a></div><span className="mono footer-status"><span className="status-dot"></span> ALL SYSTEMS BUILDING</span></div></div></footer>

      {modalOpen && <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setModalOpen(false); }}><section className="submission-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div className="modal-header"><div><div className="eyebrow">SUBMISSION PORTAL / 001</div><h2 id="modal-title">Put your build <span className="gradient-text">on the map.</span></h2><p>Share what you are making with the open-source AI community.</p></div><button className="modal-close" onClick={() => setModalOpen(false)} aria-label="Close submission form"><X size={20} /></button></div>
        <form className="submission-form" onSubmit={submitProject}>
          <div className="form-grid"><label>Project name <span>*</span><input name="project_name" value={form.project_name} onChange={update} placeholder="e.g. LocalMind" maxLength={100} required /></label><label>Team / developer name <span>*</span><input name="team_name" value={form.team_name} onChange={update} placeholder="e.g. The Open Builders" maxLength={100} required /></label></div>
          <label>Email address <span>*</span><input name="email" type="email" value={form.email} onChange={update} placeholder="you@example.com" maxLength={254} required /></label>
          <label>GitHub repository URL <span>*</span><input name="github_url" type="url" value={form.github_url} onChange={update} placeholder="https://github.com/you/project" required /></label>
          <label>Choose your track <span>*</span><select name="track" value={form.track} onChange={update} required>{TRACK_OPTIONS.map(t => <option key={t} value={t}>{t}</option>)}</select></label>
          <label>Demo URL <span className="optional">(optional)</span><input name="demo_url" type="url" value={form.demo_url} onChange={update} placeholder="https://your-demo.com or video link" /></label>
          <label>Short project description <span>*</span><textarea name="description" value={form.description} onChange={update} placeholder="What does it do? What makes it interesting?" rows={3} maxLength={1000} required /><small className="char-count">{form.description.length}/1000</small></label>
          {formError && <div className="form-error" role="alert">{formError}</div>}
          <div className="form-actions"><span className="form-privacy"><Check size={14} /> Your email is not shown in the public project list.</span><button className="btn-primary" type="submit" disabled={sending}>{sending ? 'Submitting…' : 'Submit project'} {sending ? <span className="button-spinner"></span> : <Send size={15} />}</button></div>
        </form><div className="modal-foot mono"><span>OPEN_SOURCE // OPEN_BUILD</span><span>REQUIRED FIELDS MARKED *</span></div>
      </section></div>}
      {toast && <div className="toast" role="status"><span className="toast-check"><Check size={17} /></span><span>{toast.message}</span><button onClick={() => setToast(null)} aria-label="Dismiss notification"><X size={15} /></button></div>}
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
