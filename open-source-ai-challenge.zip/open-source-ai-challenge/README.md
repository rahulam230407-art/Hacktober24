# OpenBuild AI — Open-Source AI Challenge

A responsive React + Vite landing page and project submission portal backed by Supabase.

## Requirements

- Node.js 20+ recommended
- A Supabase project

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

Open the local URL printed by Vite. On Windows PowerShell, use `Copy-Item .env.example .env` instead of `cp`.

The `.env.example` contains the project URL and publishable browser key supplied for this build. Environment variables prefixed with `VITE_` are bundled into client-side code. **Only use a Supabase publishable/anon key here; never use a `service_role` or secret key in the browser.**

## Configure Supabase

1. Open the Supabase project dashboard.
2. Go to **SQL Editor** and run all of `supabase/schema.sql`.
3. In **Project Settings → API**, verify the project URL and publishable key match `.env`.
4. Start/restart Vite after editing `.env`.

The form inserts into `public.submissions`. The public list reads from the `public_submissions` view, which omits email addresses. The SQL sets RLS, validates tracks, and gives anonymous visitors insert permission without allowing them to query the base table. Realtime is enabled for new submission events when the `supabase_realtime` publication is available.

If Realtime is unavailable in your project, the manual **Refresh** button and post-submit refresh still work.

## Build for deployment

```bash
npm run build
npm run preview
```

Deploy the generated `dist/` folder to Vercel, Netlify, Cloudflare Pages, or another static host. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` to the hosting provider's environment variables, then redeploy.

## Included features

- Responsive dark developer-focused interface
- Track cards that preselect the submission track
- Accessible guidelines accordion and modal dialog semantics
- Client-side validation and visible database errors
- Supabase submission insert, public leaderboard view, and realtime refresh
- SEO description, OpenGraph metadata, and theme color
- Starter resources for Hugging Face, Ollama, GitHub, Transformers, llama.cpp, and LangGraph

## Before a public launch

- Add rate limiting / bot protection (for example, a CAPTCHA plus server-side verification) to reduce spam.
- Consider a moderation or approval workflow before displaying submissions publicly.
- Replace the placeholder email links for Privacy and Terms with real policy pages and contact details.
- If you add auth or admin features, keep privileged operations server-side.
