-- Run this in Supabase Dashboard > SQL Editor.
-- The public key belongs in the browser; never put a service_role key in frontend code.

create extension if not exists pgcrypto;

create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  project_name text not null check (char_length(trim(project_name)) between 1 and 100),
  team_name text not null check (char_length(trim(team_name)) between 1 and 100),
  email text not null check (char_length(trim(email)) between 3 and 254),
  github_url text not null check (github_url ~* '^https?://(www\.)?github\.com/[^/]+/[^/?#]+'),
  track text not null check (track in ('Open-Weight Models', 'Agent Frameworks', 'Local Inference', 'Combined')),
  demo_url text,
  description text not null check (char_length(trim(description)) between 1 and 1000)
);

alter table public.submissions enable row level security;

-- Public visitors can submit entries, but cannot select email addresses from the base table.
revoke all on table public.submissions from anon, authenticated;
grant insert on table public.submissions to anon, authenticated;
-- Column-level SELECT lets the public leaderboard and Realtime work without exposing email.
grant select (id, created_at, project_name, team_name, github_url, track, demo_url, description)
  on table public.submissions to anon, authenticated;

drop policy if exists "Anyone can submit a project" on public.submissions;
drop policy if exists "Public can read leaderboard fields" on public.submissions;
create policy "Public can read leaderboard fields"
on public.submissions for select
to anon, authenticated
using (true);

create policy "Anyone can submit a project"
on public.submissions for insert
to anon, authenticated
with check (
  char_length(trim(project_name)) between 1 and 100
  and char_length(trim(team_name)) between 1 and 100
  and char_length(trim(email)) between 3 and 254
  and track in ('Open-Weight Models', 'Agent Frameworks', 'Local Inference', 'Combined')
  and char_length(trim(description)) between 1 and 1000
);

-- Public leaderboard projection excludes private email data.
drop view if exists public.public_submissions;
create view public.public_submissions
with (security_barrier = true)
as
select id, created_at, project_name, team_name, github_url, track, demo_url, description
from public.submissions;

grant select on public.public_submissions to anon, authenticated;

-- Enable Realtime for the submissions table so the client can refresh on new rows.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'submissions'
  ) then
    alter publication supabase_realtime add table public.submissions;
  end if;
exception when undefined_object then
  raise notice 'supabase_realtime publication not found; enable Realtime for submissions in the dashboard.';
end $$;
